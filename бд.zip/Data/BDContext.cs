﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using BD_of_the_Insurance_Company.Models;

namespace BD.Data
{
    public class BDContext : DbContext
    {
        public BDContext (DbContextOptions<BDContext> options)
            : base(options)
        {
        }

        public DbSet<BD_of_the_Insurance_Company.Models.Risks> Risks { get; set; }

        public DbSet<BD_of_the_Insurance_Company.Models.Staff> Staff { get; set; }
    }
}
